function y=set_font(nr_fig,fontsize);

figure(nr_fig);
h=title(' ');
set(h,'FontSize',fontsize);

