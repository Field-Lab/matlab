function imp=el_imp_mod1(Ce,beta,Re,warburg,Rs,f);

zcpe=Ce*(i*2*pi*f).^(-beta);
a=zcpe+Re;
b=zcpe*Re;
z1=b./a;
imp=z1+Rs;