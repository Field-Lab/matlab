function DiffEI=NS_PrintDiffEIs(StimElectrode,RecElectrodes,MovieNumber1,MovieNumber2,BadChannels,ReadPath,FileName,WritePath);

[DiffEI]=NS_PlotDiffEIsOnArrayLayout(StimElectrode,MovieNumber1,MovieNumber2,RecElectrodes,BadChannels,ReadPath,FileName,WritePath);        
