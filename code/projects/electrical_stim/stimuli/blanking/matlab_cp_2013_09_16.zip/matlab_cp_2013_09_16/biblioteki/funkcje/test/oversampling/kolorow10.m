function kolor=kolorow10(i);

colors=zeros(10,3);
colors(1,:)=[1 0 0];
colors(2,:)=[0 1 0];
colors(3,:)=[0 0 1];
colors(4,:)=[1 0 1];
colors(5,:)=[0.9 0.9 0];
colors(6,:)=[0 0.9 0.9];
colors(7,:)=[0 0 0];
colors(8,:)=[0.6 0.6 0.6];
colors(9,:)=[1 0.5 0];
colors(10,:)=[0 1 1];
colors(11,:)=[0 0.5 1];


kolor=colors(i,:)';
