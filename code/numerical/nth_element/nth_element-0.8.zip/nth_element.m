%NTH_ELEMENT wrap of C++ nth_element, an efficient rank selection algorithm
%    OUTARR = NTH_ELEMENT(INARR, RANK)
%        INARR is a 2D array of data columns
%        RANK is an integer representing the selected rank to pivot around
%
%        NTH_ELEMENT works with each column in turn and calls C++ 
%            std::nth_element to iteratively pivot until the RANK element
%            is properly placed
%
%        OUTARR is a copy of INARR with the RANK element in the proper
%            position.  All elements before RANK will be less than RANK and
%            all elements after RANK will be greater, but no further sorting
%            is guaranteed.
%
%    See C++ documentation for std::nth_element for more information.
%
%    NTH_ELEMENT will work with any numeric data type except int64.  The 
%    code has lines to handle int64 but they are commented out as the C++ 
%    datatype for int64 is not standard between different compilers.  (GCC 
%    uses "long long" while VC uses __int64.)
%
%    To compile NTH_ELEMENT, you must have MEX set up with a compiler.
%    Then go to the directory that contains nth_element.cpp and run:
%        > mex nth_element.cpp
%

% Version 0.8
% Peter  H. Li 19-Nov-2010
% Some rights reserved
% Licensed under Creative Commons
%   http://creativecommons.org/licenses/by-sa/3.0/

%    (It is possible to get even greater speed by running nth_element on
%    the input array in place.  However, MatLab does not allow this kind
%    of pass-by-reference side-effect editing of the inputs; this can
%    confuse MatLab itself and should not be attempted without careful
%    testing.)
