/* cpprand.hpp
 * Ver 0.9.7
 * Peter H. Li 2011 FreeBSD License 
 * See cpprandpar.m for more documentation.
 */

#ifndef CPPRAND_HPP
#define CPPRAND_HPP

#include <sstream>
#include "mx_functional/mx_functional.h"

// Detect C++11 compiler?  Need to test this... (copied from ../include/boost/config/compiler/gcc.hpp)
// #if (__GNUC__ > 4 || (__GNUC__ == 4 && __GNUC_MINOR__ > 2)) && defined(__GXX_EXPERIMENTAL_CXX0X__)
// #define RANDOM_NAMESPACE std
// Need to handle a bunch of other crap like uniform_01 is now uniform_01_distribution :(
// Also stringstream has to be specified differently apparently... (fixable just by adding #include <iostream>?

#ifdef CPPRAND_USE_BOOST_RANDOM_1_47
#include "boost_1_47_0/boost/random.hpp"
#define BOOST_VERSION 104700
#else
#include "boost/random.hpp"
#include "boost/version.hpp"
#endif

#if BOOST_VERSION>=104700
#define RANDOM_NAMESPACE boost::random
#else
#define RANDOM_NAMESPACE boost
#define uniform_real_distribution uniform_real
#define uniform_int_distribution uniform_int
#endif
#undef BOOST_VERSION

// Functor handling the core logic of generating pseudorandom samples.  Also
// handles on construction various ways of seeding the Mersenne Twister RNG.
// The main methods are to provide a seed, or provide an entire state string.
// 
// In the future I would like to expand this to flexibly handle different 
// RNGs.  It appears that all the generators in Boost Random implement the
// stream operators for serializing state, and they also all seem to be able
// to take some kind of int as a seed; nice!
template <class RNG = RANDOM_NAMESPACE::mt19937>
class CppRandFunct
{
public:
  CppRandFunct() {}
  CppRandFunct(RNG rng) : _rng(rng) {}
  CppRandFunct(uint32_t seed) : _rng(seed) {}
  CppRandFunct(std::string rngstatestr) {
    std::stringstream rngstate(std::stringstream::in);
    rngstate.str(rngstatestr);
    rngstate >> _rng;
  }
  
  // Must be const for parallel operation
  template <class D>
  std::string operator()(MWArrayContainer<double> out, D dist) const {
    
    // Must copy RNG so that operator() can be const
    RNG rng = _rng;
    for (mwSize i = 0; i < out.nelem(); ++i)
      out[i] = dist(rng);
    
    std::stringstream state(std::stringstream::out);
    state << rng;
    return state.str();
  }
  
private:
  RNG _rng;
};


// Simple adapter between StructToDistFunct, which must be used to 
// decode Matlab structs holding C++ distribution classes, and 
// CppRandFunct
template <class RNG = RANDOM_NAMESPACE::mt19937>
class CppRandDistFunct
{
public:
  CppRandDistFunct(CppRandFunct<RNG> crf, MWArrayContainer<double> out) : _crf(crf), _out(out) {}

  template <typename D>
  std::string operator()(D dist) const {
    return _crf(_out, dist);
  }
  
private:
  CppRandFunct<RNG> _crf;
  MWArrayContainer<double> _out;
};


#endif
