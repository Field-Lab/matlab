/* cpprand.cpp
 * Ver 0.80
 * Peter H. Li 2011 FreeBSD License 
 * See cpprand.m for documentation
 */

#include "mex.h"
#include "cpprand.hpp"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {
  // Check inputs
  if (nrhs != 3)
    mexErrMsgIdAndTxt("cpprand:nrhs", "Arguments should be M and N dimensions and a starting seed/state");
  if (!mxIsNumeric(prhs[0]) || !mxIsNumeric(prhs[1]) || mxGetNumberOfElements(prhs[0]) != 1 || mxGetNumberOfElements(prhs[1]) != 1)
    mexErrMsgIdAndTxt("cpprand:prhs", "First and second arguments should be scalars giving the M and N dimensions");
  
  // Last argument can either be a uint32 seed, or a char array of the full state
  CppRandFunct<> cpprandfunct;
  switch (mxGetClassID(prhs[2])) {
    case mxUINT32_CLASS:
      if (mxGetNumberOfElements(prhs[2]) != 1)
        mexErrMsgIdAndTxt("cpprand:prhs", "3rd argument should be a scalar uint32 seed, or a char array of previous state");
      cpprandfunct = CppRandFunct<>(*static_cast<unsigned int *>(mxGetData(prhs[2])));
      break;
    case mxCHAR_CLASS:
      cpprandfunct = CppRandFunct<>(mxArrayToString(prhs[2]));
      break;
    default:
      mexErrMsgIdAndTxt("CPPRAND:prhs", "3rd argument should be uint32 seed or state string");
  }

  // Create output matrix
  plhs[0] = mxCreateDoubleMatrix(mxGetScalar(prhs[0]), mxGetScalar(prhs[1]), mxREAL);

  // Get random numbers, save end state of RNG
  std::string outstate = cpprandfunct(MWArrayContainer<double>(plhs[0]));
  
  // Copy ending state string to output if requested
  if (nlhs > 1) plhs[1] = mxCreateString(outstate.c_str());
}