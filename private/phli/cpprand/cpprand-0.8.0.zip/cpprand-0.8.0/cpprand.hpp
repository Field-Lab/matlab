/* cpprand.hpp
 * Ver 0.80
 * Peter H. Li 2011 FreeBSD License 
 * See cpprandpar.m for documentation.
 */

#include <iostream>
#include <sstream>
#include "mx_functional/mx_functional.h"
#include "boost/version.hpp"
#include "boost/random/mersenne_twister.hpp"
#include "boost/random/uniform_01.hpp"

#if BOOST_VERSION>=104700
#define BOOST_RANDOM_NAMESPACE boost::random
#else
#define BOOST_RANDOM_NAMESPACE boost
#endif

template <class RNG = BOOST_RANDOM_NAMESPACE::mt19937>
class CppRandFunct
{
public:
  CppRandFunct() {}
  CppRandFunct(RNG rng) : _rng(rng) {}
  CppRandFunct(uint32_t seed) : _rng(seed) {}
  CppRandFunct(std::string statestr) {
    std::stringstream state(std::stringstream::in);
    state.str(statestr);
    state >> _rng;
  }
  
  // Must be const for parallel operation
  std::string operator()(MWArrayContainer<double> out) const {
      
    // Must copy RNG so that operator() can be const
    RNG rng = _rng;
    
    BOOST_RANDOM_NAMESPACE::uniform_01<> uniform01;
    for (mwSize i = 0; i < out.nelem(); ++i)
      out[i] = uniform01(rng);

    std::stringstream state(std::stringstream::out);
    state << rng;
    return state.str();
}
  
private:
  RNG _rng;
};
