% CREATEDIST    Brings flexible C++ random distributions into Matlab
% usage: d = createdist('poisson_distribution');
%        d = createdist('poisson_distribution', 3);
%        d = createdist('normal_distribution', [0 1.5]);
%
% then: A = cpprand(10000, 100, uint32(5489), d) % Generate random samples on distribution d
%
% They can all be called without parameters for a default version, or with 
% parameters (usually listed in a numeric vector).
%
% Implemented so far:
%   uniform_01
%   uniform_smallint,           parameters: [min max]
%   uniform_int_distribution,   parameters: [min max]
%   uniform_real_distribution,  parameters: [min max]
%   poisson_distribution,       parameter: mean
%   normal_distribution,        parameters: [mean sigma]
%   triangle_distribution,      parameters: [a b c]
%
%   piecewise_linear_distribution, for this give a 2xN or Mx2 matrix where
%   the first row/column is the values and the second is the probability
%   weights
%
% In general, probabilities do not need to be normalized.
%
%
% Available in Boost Random:
%   http://www.boost.org/doc/libs/1_47_0/doc/html/boost_random/reference.html#boost_random.reference.distributions 
% (If you need one that I haven't wired in yet, shoot me an email).
%

% Version 0.9.5
% Peter H. Li 27-Sep-2011
% As required by MatLab Central FileExchange, licensed under the FreeBSD License