/* cpprand_dist2struct.hpp
 * Version 0.3.0
 * Peter H. Li 2011 FreeBSD License
 * Converting from generic distribution classes to Matlab struct arrays
 * 
 * C++ probability distribution classes allow a single RNG to flexibly generate
 * samples from many underlying distributions, including the user-definable 
 * piecewise_linear_distribution and discrete_distribution.  These classes are
 * required to override the stream operators (<< and >>) to implement string
 * based serialization of their internal state.  Thus it is not too painful to
 * bring the flexibility of distribution classes into Matlab by allowing the
 * mex file createdist.cpp to build a C++ ditstribution object and return it
 * to Matlab in its serialized state, and then allow Matlab to pass the 
 * serialized string back into C++ to get random samples.
 *
 * There was of course still a little futzing required to get this working.  
 * I had to decide on a Matlab data structure to store the serialized 
 * distribution objects.  It wasn't easy to return a Matlab OO object from 
 * C++, so in the end I decided to stick with a simple struct array.
 * 
 * The logic here is used primarily to convert from C++ distributions to
 * a Matlab struct, while cpprand_struct2dist deals with the reverse
 * conversion.
 */

#ifndef CPPRAND_DIST2STRUCT_HPP
#define CPPRAND_DIST2STRUCT_FPP

#include <sstream>
#include "cpprand.hpp"


// Essentially just a map from distribution types to strings.  There are
// various ways to implement this but this seemed cleanest in the end and
// there are not so many types as to make this a total pain.
template <typename D> char *get_disttype();
template <> char *get_disttype<RANDOM_NAMESPACE::uniform_01<>                    >() { return "uniform_01"; }
template <> char *get_disttype<RANDOM_NAMESPACE::uniform_smallint<>              >() { return "uniform_smallint"; }
template <> char *get_disttype<RANDOM_NAMESPACE::uniform_int_distribution<>      >() { return "uniform_int_distribution"; }
template <> char *get_disttype<RANDOM_NAMESPACE::uniform_real_distribution<>     >() { return "uniform_real_distribution"; }
template <> char *get_disttype<RANDOM_NAMESPACE::poisson_distribution<>          >() { return "poisson_distribution"; }
template <> char *get_disttype<RANDOM_NAMESPACE::normal_distribution<>           >() { return "normal_distribution"; }
template <> char *get_disttype<RANDOM_NAMESPACE::piecewise_linear_distribution<> >() { return "piecewise_linear_distribution"; }
template <> char *get_disttype<RANDOM_NAMESPACE::triangle_distribution<>         >() { return "triangle_distribution"; }


// Convert from the distribution D to a Matlab struct.  The struct
// identifies itself as a CppRandDist, in place of real OO, and also
// stores the specific C++ distribution type (e.g. "uniform_01") and
// of course the state string that represents the distribution.
template <typename D>
mxArray *dist_to_struct(D dist) {
  mxArray *classname = mxCreateString("CppRandDist");
  mxArray *type = mxCreateString(get_disttype<D>());

  std::stringstream s(std::stringstream::out);
  s << dist;
  mxArray *state = mxCreateString(s.str().c_str());

  const char *fieldnames[] = {"class", "type", "state"};
  mxArray *diststruct = mxCreateStructMatrix(1, 1, 3, fieldnames);
  mxSetField(diststruct, 0, "class", classname);
  mxSetField(diststruct, 0, "type", type);
  mxSetField(diststruct, 0, "state", state);

  return diststruct;
}


#endif
