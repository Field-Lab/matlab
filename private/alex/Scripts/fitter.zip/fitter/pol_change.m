function pol_change
global AllFilters pol ind rightBorder leftBorder onUI sbpl start_trial ...
    line_id rightBorder_id leftBorder_id


if get(onUI,'Value') % on
    [~, ind]=max(AllFilters(1:200,:)); 
    pol=1;
else % off
    [~, ind]=min(AllFilters(1:200,:));    
    pol=-1;
end
ind(ind<51)=51;
rightBorder=ind+50;
leftBorder=ind-50;

for i=1:length(sbpl)
    j=start_trial+i-1;
    subplot(sbpl(i));
    a=get(gca,'YLim');
    delete(line_id(i));
    delete(rightBorder_id(i));
    delete(leftBorder_id(i));
    line_id(i)=line([ind(j),ind(j)],a,'color','k','linewidth',2);
    rightBorder_id(i)=line([rightBorder(j),rightBorder(j)],a,'color','g','linewidth',2);
    leftBorder_id(i)=line([leftBorder(j),leftBorder(j)],a,'color','g','linewidth',2);
end