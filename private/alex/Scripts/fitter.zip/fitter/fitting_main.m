clear
clc
cd('/Users/alexth/Desktop/Scripts/fitter')
path(path,'/Users/alexth/Desktop/Scripts/')

global mainGUI common_res_fit start_trial cur_unit fl path2save unit_name contr AllFilters AllTrials
fl=0;
start_trial=1;
cur_unit=1;
fittingGUI(0),