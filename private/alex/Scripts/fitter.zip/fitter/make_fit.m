function make_fit
global toFit leftBorder rightBorder ind sbpl start_trial common_res_fit pol goto spikeCount
resFit=zeros(3,goto-start_trial+1);

lower_a=0;
upper_a=1000;
lower_b=40;
upper_b=200;
lower_c=0;
upper_c=100;

for trial=1:size(toFit,2)
    tr=trial+start_trial-1;
    if spikeCount(tr)>5
        for_fit=pol*toFit(leftBorder(tr):rightBorder(tr),trial);
        
        fit_res=fit((leftBorder(tr):rightBorder(tr))',for_fit,'gauss1',...
            'Lower',[lower_a, lower_b, lower_c],...
            'Upper',[upper_a, upper_b, upper_c],...
            'Startpoint',[toFit(ind(tr),trial), ind(tr), 30]);
        resFit(1,trial)=pol*fit_res.a1;
        resFit(2,trial)=fit_res.b1;
        resFit(3,trial)=fit_res.c1;
        
        subplot(sbpl(trial))
        hold on
        x=(leftBorder(tr):rightBorder(tr))';
        y=resFit(1,trial)*exp(-((x-resFit(2,trial))/resFit(3,trial)).^2);
        plot(x,y,'r','LineWidth',2)
        a=int2str(round(resFit(:,trial))');
        a(regexp(a,'  '))='';
        a(regexp(a,'  '))='';
        text(200,0.8*toFit(ind(tr),trial),a,'FontSize',4);        
    end
end
display('DONE')
common_res_fit(:,start_trial:start_trial+length(sbpl)-1)=resFit;