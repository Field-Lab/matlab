function fittingGUI(ifNextUnit)

global HighFilters HighSpikeCount LowFilters LowSpikeCount spike_info mainGUI...
    toFit sbpl line_id ind rightBorder leftBorder rightBorder_id leftBorder_id...    
    start_trial cur_unit pol fl path2save unit_name getLowerAUI getIniAUI...
    getUpperAUI getLowerBUI getIniBUI getUpperBUI getLowerCUI getIniCUI getUpperCUI...
    onUI offUI common_res_fit spikeCount fromUI toUI...
    filterspath filters unitspath units goto date gotoUnitUI ...
    trialsPerScreen trialsPerScreenUI infoUI onOffUI changeIndUI changeIntUI ...
    goUI nextUI saveUI nextUnitUI refitUI rejectUI AllFilters AllTrials


load(filtersFile)

tmp=strfind(filtersFile,filesep);
path2save=filtersFile(1:tmp(end));

% set parameters for GUI
trialsPerScreen=49;

h=findobj('Name',date);
if ~isempty(h)
    close(h)
end




currentUnit=1;

currentLFs=LinearFilter(:,:,currentUnit);
currentPolarity=polarity(currentUnit);
if currentPolarity==-1 %off cell
    ind=min(currentLFs(51:200,:))+50;
else
    ind=max(currentLFs(51:200,:))+50;
end    
rightBorder=ind+50;
leftBorder=ind-50;


create_figure(flag)



if fl==0; % first run
    
    pathNameInit='/Users/alexth/Dropbox/';
    [fileName,pathName] = uigetfile(pathNameInit);
    
    load([pathName,fileName]);

    date=pathName((end-1)+1:end-1);
    
    unitspath=[pathName,'easy_formatted_units/'];

    cur_unit=1;
    start_trial=1;    
    fl=1;
    if strcmp(contr,'high')
        filterspath=[pathName,'FFFlicker_LF/'];
        filters=dir([filterspath,'*filter.mat']);
        load([filterspath,filters(1).name])
        units=dir([unitspath,'*FFFlicker.mat']);
        path2save=[pathName,'fit_res_HC/'];
        AllTrials=size(HighFilters,2);
    elseif strcmp(contr,'low')
        filterspath=[pathName,'FFFlicker_LF/'];
        filters=dir([filterspath,'*filter.mat']);
        load([filterspath,filters(1).name])
        units=dir([unitspath,'*FFFlicker.mat']);
        path2save=[pathName,'fit_res_LC/'];
        AllTrials=size(LowFilters,2);
    elseif strcmp(contr,'checker')
        filterspath=[pathName,'CBFlicker_LF/'];
        filters=dir([filterspath,'*filter.mat']);
        load([filterspath,filters(1).name])
        units=dir([unitspath,'*CBFlicker.mat']);
        path2save=[pathName,'fit_res_CB/'];
        AllTrials=size(HighFilters,2);
    end
  
    
    
elseif ifNextUnit==1
    cur_unit=cur_unit+1;
    start_trial=1;
    fl=1;
elseif ifNextUnit==2    
    cur_unit=str2num(get(gotoUnitUI,'String'));
    start_trial=1;
    fl=1;
elseif ifNextUnit==3
    trialsPerScreen=str2num(get(trialsPerScreenUI,'String'));
else    
    if goto<AllTrials
        start_trial=goto+1;
        fl=fl+1;
    else
        cur_unit=cur_unit+1;
        start_trial=1;
        fl=1;
    end
end
    
if start_trial==1
    load([filterspath,filters(cur_unit).name])
    if strcmp(contr,'high') | strcmp(contr,'checker')
        AllFilters=HighFilters(1:350,:);
        AllTrials=size(HighFilters,2);  
        spikeCount=HighSpikeCount;
    else
        AllFilters=LowFilters(1:350,:);
        AllTrials=size(LowFilters,2);
        spikeCount=LowSpikeCount;
    end
    common_res_fit=zeros(3,AllTrials);
    load([unitspath,units(cur_unit).name])
    unit_name=units(cur_unit).name(1:end-27);
end

goto=min(AllTrials,trialsPerScreen*fl); %last trial to display

if start_trial==1
    myHope=std(AllFilters(50:150,:))-std(AllFilters(1:50,:))>5;
    [~, ind_max]=max(AllFilters(1:200,:));
    [~, ind_min]=min(AllFilters(1:200,:));
    if sum(ind_max(myHope)<ind_min(myHope))<sum(myHope)/2
        pol=-1; % off
        ind=ind_min;
        ind(ind<51)=51;
    else
        pol=1; % on
        ind=ind_max;
        ind(ind<51)=51;
    end    
    rightBorder=ind+50;
    leftBorder=ind-50;
end

set(onUI, 'Value',ceil(pol+0.5)/2) ;
set(offUI,'Value',~ceil(pol+0.5)/2);
set(infoUI,'String', ['Unit:  ', unit_name, '  (',int2str(cur_unit),' out of ',int2str(length(filters)),')    Trials:  ',int2str(start_trial),'-',int2str(goto),'  (out of ',int2str(AllTrials),')    ',contr,' Contrast']);
set(fromUI,'String','0');
set(toUI,'String','0');
set(gotoUnitUI,'String',num2str(cur_unit));
set(trialsPerScreenUI,'String',num2str(trialsPerScreen));


for i=1:length(sbpl)
    if ishandle(sbpl(i))
        delete(sbpl(i));
    end
end

[rows,cols]=opt_subplots(goto-start_trial+1);
toFit=AllFilters(:,start_trial:goto);
sbpl=zeros(goto-start_trial+1,1);
for i=1:goto-start_trial+1
    j=start_trial+i-1;
    sbpl(i)=subplot(rows,cols,i);
    hold off
    plot(toFit(:,i));
    axis tight    
    line_id(i)=line([ind(j),ind(j)],[min(toFit(:,i)),max(toFit(:,i))],'color','k','linewidth',2);
    rightBorder_id(i)=line([rightBorder(j),rightBorder(j)],[min(toFit(:,i)),max(toFit(:,i))],'color','g','linewidth',2);
    leftBorder_id(i)=line([leftBorder(j),leftBorder(j)],[min(toFit(:,i)),max(toFit(:,i))],'color','g','linewidth',2);
    title([int2str(i),' trial ',int2str(j),', ',int2str(spikeCount(j)),' sp']);
end

end