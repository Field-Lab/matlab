function change_id(flag)
global toFit sbpl line_id ind rightBorder_id leftBorder_id rightBorder leftBorder start_trial

[tmp,~]=ginput(1);
tmp=round(tmp);
sb2change=find(sbpl==gca);
id2change=start_trial+sb2change-1;
if flag==1
    delete(line_id(sb2change))
    ind(id2change)=tmp;
    line_id(sb2change)=line([ind(id2change),ind(id2change)],[min(toFit(:,sb2change)),max(toFit(:,sb2change))],'color','k','linewidth',2);
    
    change_right(50);    
    change_left(50);
else
    if tmp<ind(id2change)
        change_left(0)
    else
        change_right(0)        
    end
    [tmp,~]=ginput(1);
    tmp=round(tmp);
    if tmp<ind(id2change)
        change_left(0)
    else
        change_right(0)
    end
end
    function change_left(k)
        delete(leftBorder_id(sb2change))
        leftBorder(id2change)=tmp-k;
        leftBorder_id(sb2change)=line([leftBorder(id2change),leftBorder(id2change)],[min(toFit(:,sb2change)),max(toFit(:,sb2change))],'color','g','linewidth',2);
    end

    function change_right(k)
        delete(rightBorder_id(sb2change))
        rightBorder(id2change)=tmp+k;
        rightBorder_id(sb2change)=line([rightBorder(id2change),rightBorder(id2change)],[min(toFit(:,sb2change)),max(toFit(:,sb2change))],'color','g','linewidth',2);
    end
    
end
