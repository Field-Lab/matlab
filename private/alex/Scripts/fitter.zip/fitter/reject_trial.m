function reject_trial

global sbpl toFit start_trial common_res_fit spikeCount fromUI toUI

a=str2num(get(fromUI,'String'));
b=str2num(get(toUI,'String'));
if a==0 || b==0
    ginput(1);
    trial=find(sbpl==gca);
    tr=trial+start_trial-1;
    
    subplot(sbpl(trial))
    hold off
    plot(toFit(:,trial));
    axis tight
    title([int2str(trial),'  trial ',int2str(tr),', ',int2str(spikeCount(tr)),' spikes']);
    
    common_res_fit(:,tr)=[0 0 0];
else
    for i=a:b
        tr=i+start_trial-1;        
        subplot(sbpl(i))
        hold off
        plot(toFit(:,i));
        axis tight
        title([int2str(i),' trial ',int2str(tr),', ',int2str(spikeCount(tr)),' sp']);        
        common_res_fit(:,tr)=[0 0 0];
    end
end