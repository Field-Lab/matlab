function refit
global sbpl toFit pol ind leftBorder rightBorder getLowerAUI getIniAUI...
    getUpperAUI getLowerBUI getIniBUI getUpperBUI getLowerCUI getIniCUI getUpperCUI...
    line_id rightBorder_id leftBorder_id start_trial common_res_fit spikeCount

ginput(1);
trial=find(sbpl==gca);

tr=trial+start_trial-1;
lower_a=str2num(get(getLowerAUI,'String'));
upper_a=str2num(get(getUpperAUI,'String'));
lower_b=str2num(get(getLowerBUI,'String'));
upper_b=str2num(get(getUpperBUI,'String'));
lower_c=str2num(get(getLowerCUI,'String'));
upper_c=str2num(get(getUpperCUI,'String'));
ini_a=str2num(get(getIniAUI,'String'));
ini_b=str2num(get(getIniBUI,'String'));
ini_c=str2num(get(getIniCUI,'String'));

for_fit=pol*toFit(leftBorder(tr):rightBorder(tr),trial);
fit_res=fit((leftBorder(tr):rightBorder(tr))',for_fit,'gauss1',...
    'Lower',[lower_a, lower_b, lower_c],...
    'Upper',[upper_a, upper_b, upper_c],...
    'Startpoint',[ini_a,ini_b,ini_c]);
resFit(1)=pol*fit_res.a1;
resFit(2)=fit_res.b1;
resFit(3)=fit_res.c1;

subplot(sbpl(trial))
hold off
plot(toFit(:,trial));
axis tight
line_id(trial)=line([ind(tr),ind(tr)],[min(toFit(:,trial)),max(toFit(:,trial))],'color','k','linewidth',2);
rightBorder_id(trial)=line([rightBorder(tr),rightBorder(tr)],[min(toFit(:,trial)),max(toFit(:,trial))],'color','g','linewidth',2);
leftBorder_id(trial)=line([leftBorder(tr),leftBorder(tr)],[min(toFit(:,trial)),max(toFit(:,trial))],'color','g','linewidth',2);
hold on
x=(leftBorder(tr):rightBorder(tr))';
y=resFit(1)*exp(-((x-resFit(2))/resFit(3)).^2);
plot(x,y,'r','LineWidth',2)
a=int2str(round(resFit));
a(regexp(a,'  '))='';
a(regexp(a,'  '))='';
text(200,0.8*toFit(ind(tr),trial),a,'FontSize',4);
title([int2str(trial),' trial ',int2str(tr),', ',int2str(spikeCount(tr)),' sp']);
common_res_fit(:,tr)=resFit;