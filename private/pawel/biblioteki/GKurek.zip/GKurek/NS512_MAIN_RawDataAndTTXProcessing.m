clear
clc

full_path='K:\data\2010-09-14-0\data002';          
full_pathTTX='K:\data\2010-09-14-0\data009\';        
output_path = 'K:\data\2010-09-14-0\data002min009new';

log_path = 'C:\home\Pawel\nauka\temp\log.txt';

NumberOfMovies=NS512_GetNumberOfMovies(full_path);
logFid = fopen(log_path, 'w');

%MovieID=126;
tic
  for MovieID=1:NumberOfMovies
    OutputData=NS512_ProcessRawDataAndTTX(full_path, full_pathTTX, output_path, MovieID, NumberOfMovies, logFid);
  end
toc
fclose(logFid);