function bitstr = SoftReset()
bitstr = '1010_0010';
end

