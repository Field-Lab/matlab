a=importdata('0.1-5000Hz_50s.mat');
t1=a.time;
s1=a.voltage;
%t1 = t1(1:20000);
%s1 = s1(1:20000);
