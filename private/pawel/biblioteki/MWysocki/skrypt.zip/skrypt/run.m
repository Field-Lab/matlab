gui = genNeuronAnimGUI;
uiwait(gui);
global generate;
if generate
    genNeuronAnim;
end